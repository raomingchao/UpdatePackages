<?php
/* {[The file is published on the basis of YetiForce Public License that can be found in the following directory: licenses/License.html]} */
$CONFIG = [
	// Max number of notifications to display, 0 - no limits
	'MAX_NUMBER_NOTIFICATIONS' => 200,
	// Auto refresh reminders in header
	'AUTO_REFRESH_REMINDERS' => true, // Boolean
];
