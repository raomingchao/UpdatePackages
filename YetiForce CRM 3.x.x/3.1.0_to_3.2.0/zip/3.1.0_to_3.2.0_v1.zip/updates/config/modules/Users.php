<?php
/* {[The file is published on the basis of YetiForce Public License that can be found in the following directory: licenses/License.html]} */
$CONFIG = [
	// Show information about logged user in footer
	'IS_VISIBLE_USER_INFO_FOOTER' => true,
];
