<?php
/* {[The file is published on the basis of YetiForce Public License that can be found in the following directory: licenses/License.html]} */
$SOUNDS_CONFIG = [
	//Enable system sounds
	'IS_ENABLED' => true,
	//Table with file names
	'REMINDERS' => 'sound_1.mp3',
];

