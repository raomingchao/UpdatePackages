<?php
/* {[The file is published on the basis of YetiForce Public License that can be found in the following directory: licenses/License.html]} */
$languageStrings = [
	'Partners' => 'Partnerzy',
	'SINGLE_Partners' => 'Partner',
	
	//BLOCKS
	'LBL_PARTNERS_INFORMATION' => 'Informacje podstawowe',
	'LBL_CUSTOM_INFORMATION' => 'Informacje systemowe',
	'LBL_DESCRIPTION_INFORMATION' => 'Informacje Opisowe',
	
	//FIELDS
	'LBL_SUBJECT' => 'Temat',
	'LBL_NUMBER' => 'Numer',
	'LBL_CLOSED_TIME' => 'Czas zamknięcia',
	'LBL_VAT_ID' => 'NIP',
];
