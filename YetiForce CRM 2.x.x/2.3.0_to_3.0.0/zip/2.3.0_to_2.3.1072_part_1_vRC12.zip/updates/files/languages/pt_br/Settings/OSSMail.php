<?php
/* {[The file is published on the basis of YetiForce Public License that can be found in the following directory: licenses/License.html]} */

$languageStrings = [
    'OSSMail' => 'Minha Caixa de Correio',
];

$jsLanguageStrings = [
    'JS_ERROR_EMPTY' => 'Todos os campos devem ser preenchidos',
];
