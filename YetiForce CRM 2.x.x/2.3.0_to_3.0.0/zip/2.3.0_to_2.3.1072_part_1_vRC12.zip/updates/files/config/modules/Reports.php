<?php
/* {[The file is published on the basis of YetiForce Public License that can be found in the following directory: licenses/License.html]} */
$CONFIG = [
	// Maximum number of column in reports
	'MAX_REPORT_COLUMN' => 50, // Boolean
];
