<?php
/* {[The file is published on the basis of YetiForce Public License that can be found in the following directory: licenses/License.html]} */
$CONFIG = [
	// Right calendar panel visible by default
	// true - show right panel, false - hide right panel;
	'SHOW_RIGHT_PANEL' => true, // Boolean
];
