<?php
$languageStrings = [
	'AJAXChat'  => 'Chat',
];
