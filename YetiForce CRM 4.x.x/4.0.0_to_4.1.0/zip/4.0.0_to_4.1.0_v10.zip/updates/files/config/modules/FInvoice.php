<?php
/**
 * FInvoice module config
 * @package YetiForce.Config
 * @copyright YetiForce Sp. z o.o.
 * @license YetiForce Public License 2.0 (licenses/License.html or yetiforce.com)
 */
return [
	// Update the date of the last invoice in Account while saving invoice
	'UPDATE_LAST_INVOICE_DATE' => true
];
