<?php
/**
 * ISTN german translation
 * @package YetiForce.Language
 * @copyright YetiForce Sp. z o.o.
 * @license YetiForce Public License 2.0 (licenses/License.html or yetiforce.com)
 */
$languageStrings = [
	'ISTN' => 'Hinweise Lager Umsatz',
	'SINGLE_ISTN' => 'Hinweise Lager Umsatz',
	'LBL_DESCRIPTION_BLOCK' => 'Beschreibung',
	'LBL_ATTENTION_BLOCK' => 'Bemerkungen',
	'FL_ESTIMATED_DATE' => 'voraussichtlicher Zeitpunkt',
	'FL_NUMBER' => 'Nummer',
	'FL_SUBJECT' => 'Gegenstand',
	'FL_STATUS' => 'Status',
	'PLL_DRAFT' => 'Entwurf',
	'PLL_IN_REALIZATION' => 'in Realisierung',
	'PLL_OBJECTIONS' => 'Einwände',
	'PLL_FOR_APPROVAL' => 'Zur Genehmigung',
	'PLL_CANCELLED' => 'Abgebrochen',
	'PLL_ACCEPTED' => 'Akzeptiert',
	'PLL_RECEIVED' => 'Empfangen',
	'PLL_TRANSFER' => 'Übertragung',
	'PLL_DISPATCHED' => 'aufgeben',
	'FL_TYPE' => 'Typ',
];
