<?php
/**
 * OSSPasswords spanish translation
 * @package YetiForce.Language
 * @copyright YetiForce Sp. z o.o.
 * @license YetiForce Public License 2.0 (licenses/License.html or yetiforce.com)
 */
$languageStrings = [
	'LBL_VIEW_CONFIGUREPASS' => 'Configuración de contraseñas',
	'OSSPasswords' => 'Configuración de contraseñas',
];
