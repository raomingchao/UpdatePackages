<?php

return [
	'appVersion' => '4.4.0',
	'patchVersion' => '2018.08.02',
	'lib_mPDF' => '0.0.2',
	'lib_roundcube' => '0.0.48'
];
