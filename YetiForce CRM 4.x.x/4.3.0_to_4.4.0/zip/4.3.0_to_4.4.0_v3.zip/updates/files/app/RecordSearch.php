<?php

namespace App;

/**
 * Record search basic class.
 *
 * @copyright YetiForce Sp. z o.o
 * @license YetiForce Public License 3.0 (licenses/LicenseEN.txt or yetiforce.com)
 * @author Mariusz Krzaczkowski <m.krzaczkowski@yetiforce.com>
 */
class RecordSearch
{
	public $searchValue;
	public $moduleName;
	public $limit;
	public $userId;
	public $useCache = true;
	public $entityName = true;
	public $table = 'searchLabel'; //searchLabel, label
	public $operator = 'Contain'; // Contain, Begin, End, FulltextBegin, FulltextWord
	public $checkPermissions = true;
	private $moduleConditions = ['Leads' => ['where' => ['vtiger_leaddetails.converted' => 0], 'innerJoin' => ['vtiger_leaddetails' => 'csl.crmid = vtiger_leaddetails.leadid']]];

	/**
	 * Construct.
	 */
	public function __construct($searchValue, $moduleName = false, $limit = false)
	{
		$this->searchValue = $searchValue;
		$this->moduleName = $moduleName;
		if (!$limit) {
			$limit = 20;
		}
		$this->limit = (int) $limit;
		$this->userId = \App\User::getCurrentUserId();
	}

	/**
	 * Search record.
	 *
	 * @return array
	 */
	public function search()
	{
		$cacheKey = "$this->searchValue,$this->limit," . (is_array($this->moduleName) ? implode(',', $this->moduleName) : $this->moduleName);
		if ($this->useCache && Cache::has('RecordSearch', $cacheKey)) {
			return Cache::get('RecordSearch', $cacheKey);
		}
		$query = $this->getQuery();
		if ($this->limit) {
			$query->limit($this->limit);
		}
		$crmIds = $this->limit === 1 ? $query->one() : $query->all();
		if ($this->useCache) {
			Cache::save('RecordSearch', $cacheKey, $crmIds, Cache::LONG);
		}
		return $crmIds;
	}

	/**
	 * Get query.
	 *
	 * @return Db\Query()|bool
	 */
	public function getQuery()
	{
		switch ($this->table) {
			case 'searchLabel': return $this->getSearchLabelQuery();
			case 'label': return $this->getLabelQuery();
		}
		return false;
	}

	/**
	 * Get search label query.
	 *
	 * @return Db\Query()
	 */
	public function getSearchLabelQuery()
	{
		$query = (new Db\Query())->select(['csl.crmid', 'csl.setype', 'csl.searchlabel'])
			->from('u_#__crmentity_search_label csl')->innerJoin('vtiger_tab', 'csl.setype = vtiger_tab.name');
		$where = ['and', ['vtiger_tab.presence' => 0]];
		if ($this->moduleName) {
			$where[] = ['csl.setype' => $this->moduleName];
			if (is_string($this->moduleName) && isset($this->moduleConditions[$this->moduleName])) {
				$where[] = $this->moduleConditions[$this->moduleName]['where'];
				if (isset($this->moduleConditions[$this->moduleName]['innerJoin'])) {
					foreach ($this->moduleConditions[$this->moduleName]['innerJoin'] as $table => $on) {
						$query->innerJoin($table, $on);
					}
				}
			}
		} elseif ($this->entityName) {
			$where[] = ['vtiger_entityname.turn_off' => 1];
			$query->innerJoin('vtiger_entityname', 'csl.setype = vtiger_entityname.modulename');
			if (\AppConfig::search('GLOBAL_SEARCH_SORTING_RESULTS') === 2) {
				$query->orderBy('vtiger_entityname.sequence');
			}
		}
		if ($this->checkPermissions) {
			$where[] = ['like', 'csl.userid', ",$this->userId,"];
		}
		switch ($this->operator) {
			case 'Begin':
				$where[] = ['like', 'csl.searchlabel', "$this->searchValue%", false];
				break;
			case 'End':
				$where[] = ['like', 'csl.searchlabel', "%$this->searchValue", false];
				break;
			default:
			case 'Contain':
				if (strpos($this->searchValue, '*') !== false || strpos($this->searchValue, '_') !== false) {
					$where[] = ['like', 'csl.searchlabel', str_replace('*', '%', "%{$this->searchValue}%"), false];
				} else {
					$where[] = ['like', 'csl.searchlabel', $this->searchValue];
				}
				break;
			case 'FulltextBegin':
				$query->andWhere('MATCH(csl.searchlabel) AGAINST(:findvalue IN BOOLEAN MODE)', [':findvalue' => $this->searchValue . '*']);
				break;
			case 'FulltextWord':
				$query->andWhere('MATCH(csl.searchlabel) AGAINST(:findvalue IN BOOLEAN MODE)', [':findvalue' => $this->searchValue]);
				break;
		}
		return $query->andWhere($where);
	}

	/**
	 * Get label query.
	 *
	 * @return Db\Query()
	 */
	public function getLabelQuery()
	{
		$query = (new \App\Db\Query())->select(['cl.crmid', 'cl.label'])
			->from('u_#__crmentity_label cl')->innerJoin('vtiger_crmentity', 'cl.crmid = vtiger_crmentity.crmid');
		if ($this->moduleName) {
			$where[] = ['vtiger_crmentity.setype' => $this->moduleName];
		}
		switch ($this->operator) {
			case 'Begin':
				$where[] = ['like', 'cl.label', "$this->searchValue%", false];
				break;
			case 'End':
				$where[] = ['like', 'cl.label', "%$this->searchValue", false];
				break;
			default:
			case 'Contain':
				$where[] = ['like', 'cl.label', $this->searchValue];
				break;
			case 'FulltextBegin':
				$query->andWhere('MATCH(cl.label) AGAINST(:findvalue IN BOOLEAN MODE)', [':findvalue' => $this->searchValue . '*']);
				break;
			case 'FulltextWord':
				$query->andWhere('MATCH(cl.label) AGAINST(:findvalue IN BOOLEAN MODE)', [':findvalue' => $this->searchValue]);
				break;
		}
		if ($this->checkPermissions) {
			$where[] = ['like', 'vtiger_crmentity.users', ",$this->userId,"];
		}
		return $query->andWhere($where);
	}
}
