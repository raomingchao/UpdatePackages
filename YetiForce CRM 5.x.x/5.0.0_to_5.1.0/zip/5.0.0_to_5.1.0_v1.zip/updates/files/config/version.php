<?php

return [
	'appVersion' => '5.1.0',
	'patchVersion' => '2019.03.07',
	'lib_roundcube' => '0.0.67'
];
